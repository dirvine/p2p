P2P Foundation - Click & Connect
================================

Just double-click the apps to start!

P2P-Chat:
---------
• Choose option 1 to host a chat
• Choose option 2 to join a chat
• Everything else is automatic!

The app will:
- Show your three-word address
- Display what type of tunnel it's using
- Handle all the technical stuff
- Let you chat with friends

That's it! No setup needed.
