#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
osascript -e "tell application \"Terminal\" to do script \"cd '$DIR' && ./P2P-Chat; exit\""
