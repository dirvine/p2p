#!/bin/bash
echo "Testing P2P Chat..."
echo "1" | ./P2P-Chat
