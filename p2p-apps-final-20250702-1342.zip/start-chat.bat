@echo off
cd /d "%~dp0"
P2P-Chat.exe
pause
