#!/bin/bash
cd "$(dirname "$0")"
./P2P-Chat
